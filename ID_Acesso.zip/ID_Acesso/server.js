//npm init -y
//npm isntall express --save
//npm install socket.io

//para rodar a aplicação no servidor node entrar na pasta 
//cd playground/1st-release
//node .
import express from 'express'
import { appendFile } from 'fs';
import http from 'http'
import socketio from 'socket.io'

const app = express()
const server = http.createServer(app)
const sockets = socketio(server)

app.use(express.static('public'))


sockets.on('connection', (socket) => {
    const playerId = socket.id;
    const connectionTime = new Date().toLocaleString();

    const registroConexao = {
        tipo: 'conexão',
        jogador: playerId,
        horario: connectionTime,
    };
    // Grava o registro de conexão no arquivo
    appendFile('./LOG/Conected.txt', JSON.stringify(registroConexao) + '\n', (err) => {
        if (err) {
            console.error('Erro ao gravar o registro de conexão:', err);
        }
    });
    socket.on('disconnect', () => {
        const disconnectionTime = new Date().toLocaleString();

        const registroDesconexao = {
            tipo: 'desconexão',
            jogador: playerId,
            horario: disconnectionTime,
        };
        // Grava o registro de desconexão no arquivo
        appendFile('./LOG/Desconected.txt', JSON.stringify(registroDesconexao) + '\n', (err) => {
            if (err) {
                console.error('Erro ao gravar o registro de desconexão:', err);
            }
        });
    });
});
// Endpoint para registrar acessos
app.post('/api/registro', (req, res) => {
    const { login, hora } = req.body;

    if (!login || !hora) {
        return res.status(400).json({ error: 'Login e hora são obrigatórios!' });
    }

    const registro = { login, hora };

    // Caminho para o arquivo na pasta "public"
    const filePath = path.join(__dirname, 'public', 'registros.txt');

    // Salva o registro no arquivo na pasta "public"
    fs.appendFile(filePath, JSON.stringify(registro) + '\n', (err) => {
        if (err) {
            console.error('Erro ao salvar registro:', err);
            return res.status(500).json({ error: 'Erro ao salvar registro.' });
        }

        //console.log('Registro salvo:', registro);
        res.status(201).json({ message: 'Registro salvo com sucesso!' });
    });
});
server.listen(3000, () => {
    console.log(`> Server listening on port: 3000`)
})